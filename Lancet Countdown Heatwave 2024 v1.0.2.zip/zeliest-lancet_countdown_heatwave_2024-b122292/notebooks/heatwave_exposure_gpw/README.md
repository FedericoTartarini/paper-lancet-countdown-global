Code to calculate heatwave exposure based on the GPW data, as was done in the 2023 version of the code.

The population data is available at:  https://zenodo.org/records/6011021