Prepare WorldPop data by regridding to ERA5 grid and calculate exposure to heatwaves, as well as change in heatwaves
(could be ignored in the future, not part of this year's report appendix)